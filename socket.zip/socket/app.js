var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'dev5.etech@gmail.com',
    pass: 'YogeshJalodara'
  }
});


app.get('/', function(req, res) {
   res.sendfile('index.html');
});

//Whenever someone connects this gets executed
io.on('connection', function(socket) {

    var mailOptions = {
      from: 'jalodarajayeshd@gmail.com',
      to: 'dev5.etech@gmail.com',
      subject: 'Sending Email using Node.js',
      text: 'That was easy!'
    };  
    
    transporter.sendMail(mailOptions, function(error, info){
      if (error) {
        console.log(error);
      } else {
        console.log('Email sent: ' + info.response);
      }
    });

   console.log('A user connected');
    console.log(__dirname);
   //Whenever someone disconnects this piece of code executed
   socket.on('disconnect', function () {
      console.log('A user disconnected');
      socket.broadcast.emit('jayesh');

   });
});

http.listen(3000, function() {
   console.log('listening on *:3000'+__dirname);
});

